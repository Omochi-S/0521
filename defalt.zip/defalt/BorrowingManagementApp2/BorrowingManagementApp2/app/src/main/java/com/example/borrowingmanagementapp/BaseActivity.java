package com.example.borrowingmanagementapp;

import androidx.appcompat.app.AppCompatActivity;

public class BaseActivity extends AppCompatActivity {
}
