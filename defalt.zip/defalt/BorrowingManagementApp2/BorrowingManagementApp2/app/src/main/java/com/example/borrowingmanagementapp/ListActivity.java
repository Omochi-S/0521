package com.example.borrowingmanagementapp;

import android.os.Bundle;
import android.util.Log;

import androidx.appcompat.app.AppCompatActivity;

public class ListActivity extends AppCompatActivity {
    String LOG_TAG = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        LOG_TAG = getLocalClassName();
        Log.i(LOG_TAG, "onCreate");
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list);

    }
}
