package com.example.borrowingmanagementapp2;

import android.app.DatePickerDialog;
import android.graphics.Color;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

import java.util.Arrays;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

/**
 * InputActivityは入力画面のアクティビティを管理します。
 */
public class InputActivity extends AppCompatActivity {
    String LOG_TAG = "";
    static final int VIEW_ID_INDEX = 0;
    static final int RESOURCE_ID_INDEX = 1;
    private DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        LOG_TAG = getLocalClassName();

        databaseHelper = new DatabaseHelper(this);

        Log.i(LOG_TAG, "onCreate");
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_input);

        // レイアウトの調整を行う
        adjustLayout();
        //日付入力の設定を行う
        setInputDate();

        // 確認画面遷移ボタンの初期状態を設定
        updateButtonState();

        // EditTextやTextViewのリスナーを設定して、ボタンの状態を更新する
        setEditTextListeners();
        setTextViewListeners();
    }

    /**
     * adjustLayoutメソッドは、レイアウトの調整を行います。
     * EditTextとTextViewのヒントやテキストを設定します。
     */
    private void adjustLayout() {
        // EditTextのリソースIDとヒントのリソースIDを配列に格納
        int[][] editTextElements = {
                {R.id.edittext_item, R.string.hint_item},
                {R.id.edittext_serial, R.string.hint_serial},
                {R.id.edittext_borrower_last_name, R.string.hint_last_name},
                {R.id.edittext_borrower_first_name, R.string.hint_first_name},
                {R.id.edittext_location, R.string.hint_location},
                {R.id.edittext_customer, R.string.hint_customer}
        };

        // TextViewのリソースIDとテキストのリソースIDを配列に格納
        int[][] textViewElements = {
                {R.id.title_input_screen, R.string.title_new_input},
                {R.id.textview_item, R.string.label_item},
                {R.id.textview_serial, R.string.label_serial},
                {R.id.textview_borrower, R.string.label_borrower},
                {R.id.textview_borrower_last_name, R.string.label_last_name},
                {R.id.textview_borrower_first_name, R.string.label_first_name},
                {R.id.textview_borrow_date, R.string.label_borrow_date},
                {R.id.textview_schedule_return_date, R.string.label_schedule_return_date},
                {R.id.textview_location, R.string.label_location},
                {R.id.textview_returned_date, R.string.label_returned_date},
                {R.id.textview_customer, R.string.label_customer},
                {R.id.textview_input_borrow_date, R.string.label_not_entered},
                {R.id.textview_input_schedule_return_date, R.string.label_not_entered},
                {R.id.textview_input_returned_date, R.string.label_not_entered}
        };

        // EditTextのヒントを設定
        for (int[] editTextElement : editTextElements) {
            EditText editText = findViewById(editTextElement[VIEW_ID_INDEX]);
            editText.setHint(editTextElement[RESOURCE_ID_INDEX]);
        }

        // TextViewのテキストを設定
        for (int[] textViewElement : textViewElements) {
            TextView textView = findViewById(textViewElement[VIEW_ID_INDEX]);
            textView.setText(textViewElement[RESOURCE_ID_INDEX]);

            // 「未入力」というテキストの場合は文字色を灰色にする
            if (textViewElement[RESOURCE_ID_INDEX] == R.string.label_not_entered) {
                textView.setTextColor(Color.GRAY);
            }
        }

        // 確認画面遷移ボタンの調整
        Button inputButton = findViewById(R.id.button_new_check_screen);
        inputButton.setText(R.string.button_registration);
    }

    /**
     * setInputDateメソッドは、日付入力の設定を行います。
     * 特定のTextViewをクリックしたときに、DatePickerDialogが表示されます。
     */
    private void setInputDate() {
        // 日付入力用TextViewのリスト
        List<TextView> dateInputTextViews = Arrays.asList(
                findViewById(R.id.textview_input_borrow_date),
                findViewById(R.id.textview_input_schedule_return_date),
                findViewById(R.id.textview_input_returned_date)
        );

        // 各TextViewにクリックイベントを設定
        for (TextView dateInputTextView : dateInputTextViews) {
            dateInputTextView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    showDatePickerDialog(dateInputTextView);
                }
            });
        }
    }

    /**
     * showDatePickerDialogメソッドは、DatePickerDialogを表示します。
     * 日付が選択されると、その日付が対応するTextViewに表示されます。
     * @param borrowDateInputTextView 日付が入力されるTextView
     */
    private void showDatePickerDialog(final TextView borrowDateInputTextView) {
        Calendar calendar = Calendar.getInstance();
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);
        int dayOfMonth = calendar.get(Calendar.DAY_OF_MONTH);

        DatePickerDialog datePickerDialog = new DatePickerDialog(InputActivity.this,
                new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                        // 日付を選択したときの処理
                        String selectedDate = String.format(Locale.getDefault(), "%04d/%02d/%02d", year, month + 1, dayOfMonth);
                        borrowDateInputTextView.setText(selectedDate);
                        borrowDateInputTextView.setTextColor(Color.BLACK);
                        // ボタンの状態を更新
                        updateButtonState();
                    }
                }, year, month, dayOfMonth);
        datePickerDialog.show();
    }

    /**
     * EditTextのリスナーを設定し、内容が変更されたときにボタンの状態を更新します。
     */
    private void setEditTextListeners() {
        int[] editTextIds = {
                R.id.edittext_item,
                R.id.edittext_serial,
                R.id.edittext_borrower_last_name,
                R.id.edittext_borrower_first_name,
                R.id.edittext_location,
                R.id.edittext_customer
        };
        for (int editTextId : editTextIds) {
            EditText editText = findViewById(editTextId);
            editText.addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

                @Override
                public void onTextChanged(CharSequence s, int start, int before, int count) {}

                @Override
                public void afterTextChanged(Editable s) {
                    // テキストが変更されたらボタンの状態を更新
                    updateButtonState();
                }
            });
        }
    }

    /**
     * TextViewのリスナーを設定し、内容が変更されたときにボタンの状態を更新します。
     */
    private void setTextViewListeners() {
        int[] textViewIds = {
                R.id.textview_input_borrow_date,
                R.id.textview_input_schedule_return_date,
                R.id.textview_input_returned_date
        };
        for (int textViewId : textViewIds) {
            TextView textView = findViewById(textViewId);
            textView.addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

                @Override
                public void onTextChanged(CharSequence s, int start, int before, int count) {}

                @Override
                public void afterTextChanged(Editable s) {
                    // テキストが変更されたらボタンの状態を更新
                    updateButtonState();
                }
            });
        }
    }

    /**
     * updateButtonStateメソッドは、ボタンの状態を更新します。
     * EditTextが全て入力され、かつ全てのTextViewが未入力でない場合にボタンを押せるようにします。
     */
    private void updateButtonState() {
        Button inputButton = findViewById(R.id.button_new_check_screen);
        boolean enableButton = true;

        // EditTextが全て入力されているかチェック
        int[] editTextIds = {
                R.id.edittext_item,
                R.id.edittext_serial,
                R.id.edittext_borrower_last_name,
                R.id.edittext_borrower_first_name,
                R.id.edittext_location,
                R.id.edittext_customer
        };
        for (int editTextId : editTextIds) {
            EditText editText = findViewById(editTextId);
            if (editText.getText().toString().isEmpty()) {
                enableButton = false;
                break;
            }
        }

        // 全てのTextViewが未入力でないかチェック
        int[] textViewIds = {
                R.id.textview_input_borrow_date,
                R.id.textview_input_schedule_return_date,
                R.id.textview_input_returned_date
        };
        for (int textViewId : textViewIds) {
            TextView textView = findViewById(textViewId);
            if (textView.getText().toString().equals(getString(R.string.label_not_entered))) {
                enableButton = false;
                break;
            }
        }

        inputButton.setEnabled(enableButton);
    }
}
