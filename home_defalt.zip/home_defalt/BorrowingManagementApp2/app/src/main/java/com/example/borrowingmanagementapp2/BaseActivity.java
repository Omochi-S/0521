package com.example.borrowingmanagementapp2;

import androidx.appcompat.app.AppCompatActivity;

public class BaseActivity extends AppCompatActivity {
}
