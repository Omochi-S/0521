package com.example.borrowingmanagementapp2;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

// MainActivityクラスは、アプリのメイン画面を表示します。
public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    //LOG_TAGは、ログ出力時に使用されるタグです。
    String LOG_TAG = "";

    @Override
    /**
     * onCreateメソッドは、アクティビティが初めて作成されたときに呼び出されます。
     * @param savedInstanceState アクティビティの前回の状態を保存したバンドル
     */
    protected void onCreate(Bundle savedInstanceState) {
        // ログタグを設定
        LOG_TAG = getLocalClassName();
        // ログを出力
        Log.i(LOG_TAG, "onCreate");
        super.onCreate(savedInstanceState);
        // レイアウトをセット
        setContentView(R.layout.activity_main);
        // レイアウトの調整を行う
        adjustLayout();

        // ボタンのクリックリスナーを設定
        findViewById(R.id.button_search_screen).setOnClickListener(this);
        findViewById(R.id.button_input_screen).setOnClickListener(this);
    }

    @Override
    /**
     * onClickメソッドは、ボタンがクリックされたときに呼び出されます。
     * @param v クリックされたビュー
     */
    public void onClick(View v) {
        // ログを出力
        Log.i(LOG_TAG, "onClick");
        Intent intent = null;

        // クリックされたビューがnullでないかを確認
        if (v == null) {
            return;
        }

        // クリックされたビューによって適切なインテントを作成
        if (v.getId() == R.id.button_search_screen) {
            intent = new Intent(getApplicationContext(), ListActivity.class);
        } else if (v.getId() == R.id.button_input_screen) {
            intent = new Intent(getApplicationContext(), InputActivity.class);
        }

        // インテントがnullでない場合は、アクティビティを起動
        if(intent != null) {
            startActivity(intent);
        }
    }

    /**
     * adjustLayoutメソッドは、レイアウトの調整を行います。
     */
    private void adjustLayout() {
        //ヘッダータイトルの調整
        TextView titleText = findViewById(R.id.title_main_screen);
        titleText.setText(R.string.title_main);

        // 検索画面遷移ボタンの調整
        Button searchButton = findViewById(R.id.button_search_screen);
        searchButton.setText(R.string.button_search);

        // 入力画面遷移ボタンの調整
        Button inputButton = findViewById(R.id.button_input_screen);
        inputButton.setText(R.string.button_new);
    }
}
