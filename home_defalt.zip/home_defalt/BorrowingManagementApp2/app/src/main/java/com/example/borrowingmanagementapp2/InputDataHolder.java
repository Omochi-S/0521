package com.example.borrowingmanagementapp2;

public class InputDataHolder {
    private static InputDataHolder instance;

    private String item;
    private String serial;
    private String borrowerLastName;
    private String borrowerFirstName;
    private String location;
    private String customer;
    private String borrowDate;
    private String scheduleReturnDate;
    private String returnedDate;

    private InputDataHolder() {
        // デフォルトコンストラクタをプライベートにして外部からのインスタンス化を防止
    }

    public static InputDataHolder getInstance() {
        if (instance == null) {
            instance = new InputDataHolder();
        }
        return instance;
    }

    // 各フィールドのgetterとsetter
    public String getItem() {
        return item;
    }

    public void setItem(String item) {
        this.item = item;
    }

    public String getSerial() {
        return serial;
    }

    public void setSerial(String serial) {
        this.serial = serial;
    }

    public String getBorrowerLastName() {
        return borrowerLastName;
    }

    public void setBorrowerLastName(String borrowerLastName) {
        this.borrowerLastName = borrowerLastName;
    }

    public String getBorrowerFirstName() {
        return borrowerFirstName;
    }

    public void setBorrowerFirstName(String borrowerFirstName) {
        this.borrowerFirstName = borrowerFirstName;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getCustomer() {
        return customer;
    }

    public void setCustomer(String customer) {
        this.customer = customer;
    }

    public String getBorrowDate() {
        return borrowDate;
    }

    public void setBorrowDate(String borrowDate) {
        this.borrowDate = borrowDate;
    }

    public String getScheduleReturnDate() {
        return scheduleReturnDate;
    }

    public void setScheduleReturnDate(String scheduleReturnDate) {
        this.scheduleReturnDate = scheduleReturnDate;
    }

    public String getReturnedDate() {
        return returnedDate;
    }

    public void setReturnedDate(String returnedDate) {
        this.returnedDate = returnedDate;
    }
}

