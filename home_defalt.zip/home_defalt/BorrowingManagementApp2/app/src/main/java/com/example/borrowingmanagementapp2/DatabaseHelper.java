package com.example.borrowingmanagementapp2;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class DatabaseHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "borrowing_management.db";
    private static final int DATABASE_VERSION = 1;

    // コンストラクタ
    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    // データベースが作成されたときに呼ばれる
    @Override
    public void onCreate(SQLiteDatabase db) {
        // テーブルの作成など、初期化処理を行う
        // ここで必要なテーブルの作成SQLを実行する
        db.execSQL("CREATE TABLE IF NOT EXISTS borrowings (_id INTEGER PRIMARY KEY AUTOINCREMENT, item TEXT, borrower TEXT)");
    }

    // データベースのバージョンが上がったときに呼ばれる
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // データベースのアップグレード処理を行う
        // 例えば、既存のテーブルを変更する場合は、ここでALTER TABLE文を実行する
    }

    // データベース内のレコードをすべて取得する
    public Cursor getAllRecords() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM borrowings", null);
    }

    // データベースに新しいレコードを追加する
    public long addRecord(String item, String borrower) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("item", item);
        values.put("borrower", borrower);
        return db.insert("borrowings", null, values);
    }

    // データベース内の特定のレコードを更新する
    public int updateRecord(int id, String item, String borrower) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("item", item);
        values.put("borrower", borrower);
        return db.update("borrowings", values, "_id = ?", new String[] { String.valueOf(id) });
    }

    // データベース内の特定のレコードを削除する
    public int deleteRecord(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete("borrowings", "_id = ?", new String[] { String.valueOf(id) });
    }
}
