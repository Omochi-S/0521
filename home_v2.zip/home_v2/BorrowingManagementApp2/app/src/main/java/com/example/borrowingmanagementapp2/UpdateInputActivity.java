package com.example.borrowingmanagementapp2;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.example.borrowingmanagementapp2.view.InputDateView;
import com.example.borrowingmanagementapp2.view.InputTextView;

/**
 * UpdateInputActivityは入力画面のアクティビティを管理します。
 */
public class UpdateInputActivity extends AppCompatActivity  implements View.OnClickListener {
    private static final String LOG_TAG = UpdateInputActivity.class.getSimpleName();

    //入力状況
    private static final String REQUIRED = "required";
    private static final String OPTIONAL = "optional";

    private static final int KEY = 0;
    private static final int VIEW_ID = 1;
    private static final int CONDITION = 2;

    private static final String[][] INPUT_DATA = {
            {TemporaryStorage.KEY_ITEM, "input_text_update_input_item", REQUIRED},
            {TemporaryStorage.KEY_SERIAL, "input_text_update_input_serial", REQUIRED},
            {TemporaryStorage.KEY_BORROWER, "input_text_update_input_borrower", REQUIRED},
            {TemporaryStorage.KEY_BORROW_DATE, "input_date_update_input_borrow", REQUIRED},
            {TemporaryStorage.KEY_SCHEDULE_RETURN_DATE, "input_date_update_input_schedule_return", REQUIRED},
            {TemporaryStorage.KEY_LOCATION, "input_text_update_input_location", REQUIRED},
            {TemporaryStorage.KEY_RETURNED_DATE, "input_date_update_input_returned", OPTIONAL},
            {TemporaryStorage.KEY_CUSTOMER, "input_text_update_input_customer", REQUIRED}
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        //ログを出力
        Log.i(LOG_TAG, "onCreate");
        super.onCreate(savedInstanceState);

        //レイアウトをセット
        setContentView(R.layout.activity_update_input);
        // レイアウトの調整を行う
        adjustLayout();
    }

    @Override
    protected void onStart() {
        super.onStart();
        // 一時保存データを削除
        TemporaryStorage.getInstance().clearAllData();
    }

    @Override
    public void onClick(View v) {
        Log.d(LOG_TAG, "Button clicked with ID: " + v.getId());
        Intent intent = null;

        // クリックされたビューがnullでないかを確認
        if (v == null) {
            Log.w(LOG_TAG, "Clicked view is null");
            return;
        }

        // 適切なインテントを作成
        if (v.getId() == R.id.button_update_input_update) {
            // 必須項目が全て入力されているかどうかを確認
            if (areRequiredFieldsFilled()) {
                intent = new Intent(getApplicationContext(), NewCheckActivity.class);
                saveDataToTemporaryStorage();
                Log.i(LOG_TAG, "Navigating to NewCheckActivity");
            } else {
                // 必須項目が全て入力されていない場合はToastを表示して処理を中断
                Toast.makeText(getApplicationContext(), R.string.warning_not_entered, Toast.LENGTH_SHORT).show();
                return;
            };
        } else if (v.getId() == R.id.button_update_input_delete) {
            finish();
        }

        // インテントがnullでない場合は、アクティビティを起動
        if(intent != null) {
            startActivity(intent);
        } else {
            Log.e(LOG_TAG, "Intent is null for view ID: " + v.getId());
        }
    }

    /**
     * adjustLayoutメソッド
     * レイアウトの調整
     */
    private void adjustLayout() {

        //ヘッダーの設定
        TextView titleTextView = findViewById(R.id.textview_update_input_title);
        titleTextView.setText(R.string.title_update_input);

        // 画面遷移ボタンの調整
        Button deleteButton = findViewById(R.id.button_update_input_delete);
        deleteButton.setText(R.string.button_delete);
        deleteButton.setOnClickListener(this);

        Button updateeButton = findViewById(R.id.button_update_input_update);
        updateeButton.setText(R.string.button_update);
        updateeButton.setOnClickListener(this);
    }


    /**
     * areRequiredFieldsFilledメソッド
     * 必須項目がすべて入力されているかどうかをチェック
     * @return 必須項目がすべて入力されている場合はtrue、そうでない場合はfalse
     */
    private boolean areRequiredFieldsFilled() {
        for (String[] data : INPUT_DATA) {
            if (data[CONDITION].equals(REQUIRED)) {
                // 入力項目のビューIDを取得
                int viewId = getResources().getIdentifier(data[VIEW_ID], "id", getPackageName());
                // ビューが見つからない場合はログを出力して次のループに進む
                if (viewId == 0) {
                    Log.e(LOG_TAG, "View not found for ID: " + data[VIEW_ID]);
                    continue;
                }
                // ビューを取得
                View inputView = findViewById(viewId);
                // 入力値の初期化
                String value = "";
                // ビューの種類に応じて値を取得
                if (inputView instanceof InputTextView) {
                    value = ((InputTextView) inputView).getEditTextValue();
                } else if (inputView instanceof InputDateView) {
                    value = ((InputDateView) inputView).getDateTextValue();
                }
                // 必須項目が空であればfalseを返す
                if (value.isEmpty()) {
                    return false;
                }
            }
        }
        // 必須項目が全て入力されている場合はtrueを返す
        return true;
    }

    /**
     * saveDataToTemporaryStorageメソッド
     * 入力されたデータを一時的なストレージに保存
     * 入力されたデータは、品名、シリアル番号、借用者、借用日、返却予定日、使用場所、返却日、顧客名の各項目から取得
     */
    private void saveDataToTemporaryStorage() {
        for (String[] data : INPUT_DATA) {
            // 入力項目のビューIDを取得
            int viewId = getResources().getIdentifier(data[VIEW_ID], "id", getPackageName());
            // ビューが見つからない場合はログを出力して次のループに進む
            if (viewId == 0) {
                Log.e(LOG_TAG, "View not found for ID: " + data[VIEW_ID]);
                continue;
            }
            // ビューを取得
            View inputView = findViewById(viewId);
            // 入力値の初期化
            String value = "";
            // ビューの種類に応じて値を取得
            if (inputView instanceof InputTextView) {
                value = ((InputTextView) inputView).getEditTextValue();
            } else if (inputView instanceof InputDateView) {
                value = ((InputDateView) inputView).getDateTextValue();
            }
            // 取得した値をログに出力
            Log.d(LOG_TAG, inputView.getContentDescription() + " value retrieved: " + value);
            // 取得した値を一時的なストレージに保存
            TemporaryStorage.getInstance().saveData(data[KEY], value);
        }
    }
}
