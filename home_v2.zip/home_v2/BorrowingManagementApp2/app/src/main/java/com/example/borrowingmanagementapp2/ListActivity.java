package com.example.borrowingmanagementapp2;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class ListActivity extends AppCompatActivity {
    private static final String LOG_TAG = ListActivity.class.getSimpleName();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.i(LOG_TAG, "onCreate called");
        setContentView(R.layout.activity_list);
        adjustLayout();

        ListView listView = findViewById(R.id.listview_data);

        // データベースからすべての行を取得
        DatabaseHelper dbHelper = new DatabaseHelper(this);
        Cursor cursor = dbHelper.getAllData();

        // カーソルからデータを取得し、表示するアダプターを作成
        SimpleCursorAdapter adapter = new SimpleCursorAdapter(
                this,
                android.R.layout.simple_list_item_1, // 1行のレイアウト
                cursor,
                new String[]{DatabaseHelper.COLUMN_ITEM}, // 表示する列
                new int[]{android.R.id.text1}, // 表示するViewのID
                0);

        // ListViewにアダプターを設定
        listView.setAdapter(adapter);

        // ListViewのアイテムがクリックされたときのリスナーを設定
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                // クリックされたアイテムのデータを取得してTemporaryStorageに保存
                Cursor cursor = (Cursor) parent.getItemAtPosition(position);
                String serial = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_SERIAL));
                TemporaryStorage.getInstance().saveData("selected_serial", serial);

                // UpdateInputActivityを開始
                Intent intent = new Intent(ListActivity.this, UpdateInputActivity.class);
                startActivity(intent);
            }
        });
    }

    private void adjustLayout() {
        TextView textView = findViewById(R.id.textview_list_title);
        textView.setText(R.string.title_list);
    }
}
