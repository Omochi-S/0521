package com.example.borrowingmanagementapp2.view;
//TODO:入力制限が未設定
import android.content.Context;
import android.content.res.TypedArray;
import android.text.InputFilter;
import android.text.Spanned;
import android.util.AttributeSet;
import android.util.Log;
import android.view.LayoutInflater;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.example.borrowingmanagementapp2.R;

/**
 * InputTextViewクラス
 * Textを入力するためのカスタムビュー
 */
public class InputTextView extends LinearLayout {

    private static final String LOG_TAG = InputTextView.class.getSimpleName();

    private TextView textView;
    private EditText editText;
    private TextView warningTextView;

    // 入力タイプの定数
    public static final int INPUT_TYPE_HALF_WIDTH = 0;
    public static final int INPUT_TYPE_FULL_WIDTH = 1;
    private int inputType;

    /**
     * コンストラクタ
     * @param context コンテキスト
     */
    public InputTextView(Context context) {
        super(context);
        init(context, null);
    }

    /**
     * コンストラクタ
     * @param context コンテキスト
     * @param attrs 属性セット
     */
    public InputTextView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init(context, attrs);
    }

    /**
     * コンストラクタ
     * @param context コンテキスト
     * @param attrs 属性セット
     * @param defStyleAttr デフォルトスタイル
     */
    public InputTextView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init(context, attrs);
    }

    /**
     * initメソッド
     * カスタムビューを初期化
     * @param context コンテキスト
     * @param attrs 属性セット
     */
    private void init(Context context, AttributeSet attrs) {
        LayoutInflater.from(context).inflate(R.layout.view_input_text, this, true);

        textView = findViewById(R.id.textview_input_text_item);
        editText = findViewById(R.id.edittext_input_text_entry);
        warningTextView = findViewById(R.id.textview_input_text_warning);

        Log.d(LOG_TAG, "Views initialized");

        // EditTextにInputFilterを設定
        updateInputFilter();

        // XMLで指定された属性を読み取り、TextViewとEditTextに適用
        if (attrs != null) {
            TypedArray a = context.obtainStyledAttributes(attrs, R.styleable.InputTextView);

            // TextViewのテキストを設定
            String textViewText = a.getString(R.styleable.InputTextView_textViewInputTextItem);
            if (textViewText != null) {
                textView.setText(textViewText);
                Log.d(LOG_TAG, "TextView text set from XML attributes: " + textViewText);
            }

            // EditTextのヒントを設定
            String editTextHint = a.getString(R.styleable.InputTextView_editTextInputTextHint);
            if (editTextHint != null) {
                editText.setHint(editTextHint);
                Log.d(LOG_TAG, "EditText hint set from XML attributes: " + editTextHint);
            }

            // 警告用TextViewのテキストを設定
            String warningTextViewText = a.getString(R.styleable.InputTextView_textViewInputTextWarning);
            if (warningTextViewText != null) {
                warningTextView.setText(warningTextViewText);
                Log.d(LOG_TAG, "Warning TextView text set from XML attributes: " + warningTextViewText);
            }
            a.recycle();
        }
    }

    /**
     * setTextViewTextメソッド
     * TextViewのテキストを設定
     * @param text テキスト
     */
    public void setTextViewText(String text) {
        textView.setText(text);
        Log.d(LOG_TAG, "TextView text set: " + text);
    }

    /**
     * setEditTextHintメソッド
     * EditTextのヒントを設定
     * @param hint ヒント
     */
    public void setEditTextHint(String hint) {
        editText.setHint(hint);
        Log.d(LOG_TAG, "EditText hint set: " + hint);
    }

    /**
     * setWarningTextViewTextメソッド
     * 警告用TextViewのテキストを設定
     * @param text テキスト
     */
    public void setWarningTextViewText(String text) {
        warningTextView.setText(text);
        Log.d(LOG_TAG, "Warning TextView text set: " + text);
    }

    /**
     * getEditTextValueメソッド
     * EditTextに入力されたテキストを取得
     * @return 入力されたテキスト
     */
    public String getEditTextValue() {
        String value = editText.getText().toString();
        Log.d(LOG_TAG, "EditText value retrieved: " + value);
        return value;
    }

    /**
     * setInputFilterメソッド
     * 入力制限を設定
     * @param type 入力タイプ（INPUT_TYPE_HALF_WIDTH: 半角英数文字のみ、INPUT_TYPE_FULL_WIDTH: 全角文字のみ）
     */
    public void setInputFilter(int type) {
        inputType = type;
        updateInputFilter();
        Log.d(LOG_TAG, "Input filter set to type: " + type);
    }

    /**
     * updateInputFilterメソッド
     * EditTextのInputFilterを更新
     */
    private void updateInputFilter() {
        // EditTextに入力制限を設定するInputFilterを定義
        InputFilter filter = new InputFilter() {
            @Override
            public CharSequence filter(CharSequence source, int start, int end, Spanned dest, int dstart, int dend) {
                StringBuilder builder = new StringBuilder();
                // 入力された文字列をループしてフィルタリング
                for (int i = start; i < end; i++) {
                    char c = source.charAt(i);
                    // 半角英数文字のみを入力できる場合
                    if (inputType == INPUT_TYPE_HALF_WIDTH) {
                        if ((c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z') || (c >= '0' && c <= '9')) {
                            builder.append(c);
                        } else {
                            // 入力が無効な場合は空文字を返す
                            builder.append("");
                        }
                    } else if (inputType == INPUT_TYPE_FULL_WIDTH) {
                        // 全角文字のみを入力できる場合
                        //TODO:未実装
                        builder.append(c);
                    }
                }
                // 入力が無効な場合は空文字を返す
                boolean allCharactersValid = (builder.length() == end - start);
                Log.d(LOG_TAG, "Filtering input: " + source + " -> " + builder.toString());
                return allCharactersValid ? null : "";
            }
        };

        // EditTextにInputFilterを設定
        editText.setFilters(new InputFilter[]{filter});
        Log.d(LOG_TAG, "Input filter updated");
    }
}
