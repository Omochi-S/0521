package com.example.borrowingmanagementapp2;

import android.util.Log;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

/**
 * TemporaryStorageクラス
 * 入力された値を一時保存するクラス
 */
public class TemporaryStorage {

    private static final String TAG = TemporaryStorage.class.getSimpleName();

    private static TemporaryStorage instance;
    private Map<String, String> dataMap;

    // キーの定数
    public static final String KEY_ITEM = DatabaseHelper.COLUMN_ITEM;
    public static final String KEY_SERIAL = DatabaseHelper.COLUMN_SERIAL;
    public static final String KEY_BORROWER = DatabaseHelper.COLUMN_BORROWER;
    public static final String KEY_BORROW_DATE = DatabaseHelper.COLUMN_BORROW_DATE;
    public static final String KEY_SCHEDULE_RETURN_DATE = DatabaseHelper.COLUMN_SCHEDULE_RETURN_DATE;
    public static final String KEY_LOCATION = DatabaseHelper.COLUMN_LOCATION;
    public static final String KEY_RETURNED_DATE = DatabaseHelper.COLUMN_RETURNED_DATE;
    public static final String KEY_CUSTOMER = DatabaseHelper.COLUMN_CUSTOMER;

    /**
     * コンストラクタ
     * データマップを初期化
     */
    private TemporaryStorage() {
        dataMap = new HashMap<>();
    }

    /**
     * インスタンスを取得する
     * @return TemporaryStorageのインスタンス
     */
    public static TemporaryStorage getInstance() {
        if (instance == null) {
            instance = new TemporaryStorage();
        }
        return instance;
    }

    /**
     * データを保存する
     * @param key キー
     * @param value 値
     */
    public void saveData(String key, String value) {
        dataMap.put(key, value);
        Log.d(TAG, "Data saved with key: " + key + ", value: " + value);
    }

    /**
     * すべてのキーを取得する
     * @return すべてのキー
     */
    public Set<String> getAllKeys() {
        return dataMap.keySet();
    }


    /**
     * 指定されたキーに対応するデータを取得する
     * @param key キー
     * @return キーに対応するデータ
     */
    public String getData(String key) {
        return dataMap.get(key);
    }


    /**
     * すべてのデータを削除する
     */
    public void clearAllData() {
        dataMap.clear();
        Log.d(TAG, "All data cleared");
    }
}
