package com.example.borrowingmanagementapp2;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * DatabaseHelperクラスは、SQLiteデータベースの作成、テーブルの作成、データの追加など、
 * データベース操作のためのユーティリティクラスです。
 */
public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "borrowing_management.db";
    private static final int DATABASE_VERSION = 2; // バージョンを2に更新

    // テーブル名
    public static final String TABLE_NAME = "borrowed_items";

    // カラム名
    public static final String COLUMN_ID = "_id";
    public static final String COLUMN_SERIAL = "SERIAL";
    public static final String COLUMN_ITEM = "ITEM";
    public static final String COLUMN_BORROWER = "BORROWER";
    public static final String COLUMN_BORROW_DATE = "BORROW_DATE";
    public static final String COLUMN_SCHEDULE_RETURN_DATE = "SCHEDULE_RETURN_DATE";
    public static final String COLUMN_LOCATION = "LOCATION";
    public static final String COLUMN_RETURNED_DATE = "RETURNED_DATE";
    public static final String COLUMN_CUSTOMER = "CUSTOMER";

    /**
     * DatabaseHelperクラスのコンストラクタ
     * @param context コンテキスト
     */
    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    /**
     * onCreateメソッド
     * データベースのテーブルを作成するメソッド
     * @param db データベース
     */
    @Override
    public void onCreate(SQLiteDatabase db) {
        // テーブルを作成するクエリ
        String createTableQuery = "CREATE TABLE " + TABLE_NAME + " (" +
                COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
                COLUMN_SERIAL + " TEXT," +
                COLUMN_ITEM + " TEXT," +
                COLUMN_BORROWER + " TEXT," +
                COLUMN_BORROW_DATE + " TEXT," +
                COLUMN_SCHEDULE_RETURN_DATE + " TEXT," +
                COLUMN_LOCATION + " TEXT," +
                COLUMN_RETURNED_DATE + " TEXT," +
                COLUMN_CUSTOMER + " TEXT" +
                ")";

        // テーブルを作成
        db.execSQL(createTableQuery);
    }

    /**
     * データベースのアップグレードを行うメソッド
     *
     * @param db         データベース
     * @param oldVersion 古いバージョン番号
     * @param newVersion 新しいバージョン番号
     */
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        if (oldVersion < 2) {
            db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
            onCreate(db);
        }
    }

    /**
     * すべての行を取得するメソッド
     * @return データベースから取得したすべての行を含むCursorオブジェクト
     */
    public Cursor getAllData() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.query(TABLE_NAME, null, null, null, null, null, null);
    }

    /**
     * addDataメソッド
     * データを追加する
     * @param serial   シリアル番号
     * @param item     アイテム名
     * @param borrower 借り手の名前
     * @param borrowDate 借りた日付
     * @param scheduleReturnDate 返却予定日
     * @param location 保管場所
     * @param returnedDate 返却日
     * @param customer 顧客名
     * @return データが正常に追加された場合はtrue、既に同じシリアル番号が存在する場合はfalseを返す
     */
    public boolean addData(String serial, String item, String borrower,
                           String borrowDate, String scheduleReturnDate,
                           String location, String returnedDate, String customer) {
        SQLiteDatabase db = this.getWritableDatabase();

        // 既に同じシリアル番号が登録されているかチェック
        if (isSerialAlreadyRegistered(db, serial)) {
            db.close();
            return false; // 既に登録されている場合はfalseを返す
        }

        ContentValues values = new ContentValues();
        values.put(COLUMN_SERIAL, serial);
        values.put(COLUMN_ITEM, item);
        values.put(COLUMN_BORROWER, borrower);
        values.put(COLUMN_BORROW_DATE, borrowDate);
        values.put(COLUMN_SCHEDULE_RETURN_DATE, scheduleReturnDate);
        values.put(COLUMN_LOCATION, location);
        values.put(COLUMN_RETURNED_DATE, returnedDate);
        values.put(COLUMN_CUSTOMER, customer);

        // データを挿入
        db.insert(TABLE_NAME, null, values);
        db.close();
        return true; // 正常に追加された場合はtrueを返す
    }

    /**
     * 同じシリアル番号が既に登録されているかどうかをチェックするメソッド
     * @param db SQLiteDatabaseオブジェクト
     * @param serial チェックするシリアル番号
     * @return 同じシリアル番号が既に登録されている場合はtrue、そうでない場合はfalseを返す
     */
    private boolean isSerialAlreadyRegistered(SQLiteDatabase db, String serial) {
        String query = "SELECT * FROM " + TABLE_NAME + " WHERE " + COLUMN_SERIAL + " = ?";
        Cursor cursor = db.rawQuery(query, new String[]{serial});
        boolean isRegistered = cursor.getCount() > 0;
        cursor.close();
        return isRegistered;
    }

    /**
     * updateDataBySerialメソッド
     * 特定のシリアル番号に基づいて行を更新するメソッド
     * @param serial   シリアル番号
     * @param newData  更新するデータ
     */
    public void updateDataBySerial(String serial, ContentValues newData) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.update(TABLE_NAME, newData, COLUMN_SERIAL + " = ?", new String[]{serial});
        db.close();
    }

    /**
     * deleteDataBySerialメソッド
     * 特定のシリアル番号に基づいて行を削除するメソッド
     * @param serial シリアル番号
     */
    public void deleteDataBySerial(String serial) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_NAME, COLUMN_SERIAL + " = ?", new String[]{serial});
        db.close();
    }
}
